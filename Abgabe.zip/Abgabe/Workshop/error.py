"HALLO"
def someFunction():
        x += 1
    print(x)

def someFunction():
    nonExistentFunction()
