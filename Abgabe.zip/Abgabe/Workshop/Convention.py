def greet(name):
    print(f"Hello, {name}!")
    
greet("John")

def greet(Name):
    print(f"Hello, {Name}!")
    
greet("John")