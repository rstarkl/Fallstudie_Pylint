x = 25

if x is x:
    print(x)

class foo:
    BAR = "Ich bin der Uwe und ich bin auch dabei"

    def bier(cls):
        return print(cls.BAR)
