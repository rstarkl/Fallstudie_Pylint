def dashieristeinefunktiondieeinenvielzulangennamenhat(variable, x):
    y = None 
    if x is x:     
        y =x+variable   
        print(y) #Das hier ist ein viel zu langer Kommentar für diese eine Zeile um die erlaubten 79 Zeichen pro Zeile zu erfüllen
dashieristeinefunktiondieeinenvielzulangennamenhat(10, 10)  
